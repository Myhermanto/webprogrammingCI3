<?php
class LegalitasPT extends CI_Controller{
	function __construct(){
		parent::__construct();
        if($this->session->userdata('logged_in') !=TRUE){
            $url=base_url('login.aspx');
			redirect($url);
			
        };
		$this->load->model(['M_data']);
		$this->load->library('upload');
		$this->load->helper('download');
	}

	function index(){
		$x['data']=$this->M_data->get_all_legalitaspt();
		$this->load->view('user/v_legalitasPT',$x);
	
	}

	function save()
	{
		$kode=$this->session->userdata('kode_pt');
		$jenis = $this->input->post('xjenis',TRUE);
		$nomor = $this->input->post('xnomor',TRUE);
		$tgl = $this->input->post('tanggal',TRUE);
		$nama = $this->input->post('xnama',TRUE);
		$data=[
			"jenis_legalitas"=>$jenis,			
			"nomor_keputusan"=>$nomor,												
			"tanggal_keputusan"=>$tgl,												
			"nama_kementerian"=>$nama,																																													
			"status"=>1,												
			"kode_pt"=>$kode,												
												
		];		
		
		$this->M_data->insert_data($data,'tbllegalitas_pt');
		$this->session->set_flashdata('message','<div class="alert alert-success"><i class="fa fa-check"> Data Berhasil Tersimpan..!!</i></div>');
		redirect('Legalitas-Perguruan-Tinggi.aspx');
	}


	function update()
{

	$id=$this->input->post('kode');
	$kode=$this->session->userdata('kode_pt');
	$jenis = $this->input->post('xjenis',TRUE);
	$nomor = $this->input->post('xnomor',TRUE);
	$tgl = $this->input->post('tanggal');
	$nama = $this->input->post('xnama',TRUE);
	$where = array('id_legalitaspt' => $id);
		$data = array(
			'id_legalitaspt' =>$id,
			'jenis_legalitas'=>$jenis,			
			'nomor_keputusan'=>$nomor,						
			'tanggal_keputusan'=>$tgl,						
			'nama_kementerian'=>$nama					
		);
		
	$this->M_data->update_data($where, $data,'tbllegalitas_pt');
	$this->session->set_flashdata('message','<div class="alert alert-info"><i class="fa fa-check"> Data Berhasil Terupdate..!!</i></div>');
	redirect('Legalitas-Perguruan-Tinggi.aspx');

}


function updatefile(){
				
	$kode=$this->session->userdata('kode_pt');
	$id = $this->input->post('kode');
	$tgl= date('Y-m-d H:i:s');
	$config['upload_path'] = './assets/download_berkas_legalitasPT/';
	$config['allowed_types'] = 'pdf';
	$config['max_size'] = '10048';
	$config['file_name'] = 'File_'.date("ymdHis").$kode;

$this->upload->initialize($config);
if(!empty($_FILES['filedokumen']['name']))
{
if ($this->upload->do_upload('filedokumen'))
{
		$gbr = $this->upload->data();
		$file=$gbr['file_name'];
		// $data=$this->input->post('file');
		// $path='./assets/download_berkas_IdentitasPM/'.$data;
		// unlink($path);
		$this->db->query("UPDATE  tbllegalitas_pt  SET file_legalitas='$file',status='2', keterangan='Dalam Proses Pengecekan',post_last_update='$tgl' where id_legalitaspt='$id'");
		$this->session->set_flashdata('message','<div class="alert alert-success"><i class="fa fa-check"> File Berhasil Terupload..!!</i></div>');
		redirect('Legalitas-Perguruan-Tinggi.aspx');
	
}else{
	$this->session->set_flashdata('message','<div class="alert alert-danger"><i class="fa fa-times"> Format atau Ukuran File Tidak Sesuai..!! </i></div>');
		redirect('Legalitas-Perguruan-Tinggi.aspx');
}

}else{
	redirect('Legalitas-Perguruan-Tinggi.aspx');
} 

}


function download(){
	$id_legalitaspt=$this->uri->segment(4);
	$get_db=$this->db->query("SELECT*FROM tbllegalitas_pt where id_legalitaspt='$id_legalitaspt'");
	$q=$get_db->row_array();
	$file=$q['file_legalitas'];
	$path='./assets/download_berkas_legalitasPT/'.$file;
	$data =  file_get_contents($path);
	$name = $file;
	force_download($name, $data); 
	redirect('Legalitas-Perguruan-Tinggi.aspx');
}

function deletefile(){
	$kode=$this->input->post('xkode');
	$data=$this->input->post('file');
			$path='./assets/download_berkas_legalitasPT/'.$data;
			unlink($path);
	$this->db->query("UPDATE  tbllegalitas_pt  SET file_legalitas='',status='1', keterangan ='',post_last_update='' where id_legalitaspt='$kode'");
	$this->session->set_flashdata('message','<div class="alert alert-info"><i class="fa fa-check"> File Berhasil Terhapus..!! </i></div>');
	redirect('Legalitas-Perguruan-Tinggi.aspx');
	}

function delete(){
$kode=$this->input->post('xkode');
$data=$this->input->post('file');
		$path='./assets/download_berkas_legalitasPT/'.$data;
		unlink($path);
$this->db->query("DELETE FROM tbllegalitas_pt where id_legalitaspt='$kode'");
$this->session->set_flashdata('message','<div class="alert alert-info"><i class="fa fa-check">  Data Berhasil Terhapus..!! </i></div>');
redirect('Legalitas-Perguruan-Tinggi.aspx');
}




}