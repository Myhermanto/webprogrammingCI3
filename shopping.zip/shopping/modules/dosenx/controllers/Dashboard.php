<?php
class Dashboard extends CI_Controller{
	function __construct(){
		parent::__construct();
		if($this->session->userdata('masuk') !=TRUE){
            $url=base_url('login.aspx');
			redirect($url);
			
        };
		$this->load->model(['M_data']);
	}
	function index(){
            
			$x['pengguna'] = $this->M_data->pengguna_dashbord();        
			$x['berita'] = $this->M_data->get_pengumuman();        
			$x['penting'] = $this->M_data->get_pengumuman_penting();        
            $this->load->view('v_dashboard',$x);
       
	
	}
	
}