<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dosenx extends CI_Controller{
  

    function __construct()
	{
		parent::__construct();
        //load library form validasi
		$this->load->library('form_validation');
        //load model admin
        $this->load->model('M_data');
		
    }
    function index(){
               $this->load->view('v_login');
    }

    function lupapassword(){
        $this->load->view('v_lupass');
}
    function auth(){
        $username=strip_tags(str_replace("'", "", $this->input->post('username')));
        $password=strip_tags(str_replace("'", "", $this->input->post('password')));
        $cadmin=$this->M_data->cekadmin($username,$password);
        
        if($cadmin->num_rows() > 0){
         $this->session->set_userdata('masuk',true);
         $this->session->set_userdata('nama',$username);
         $xcadmin=$cadmin->row_array();
         if($xcadmin['akses']=='1'){
            $this->session->set_userdata('akses','1');
            $idadmin=$xcadmin['nip'];
            $username=$xcadmin['nama'];
   
            $this->session->set_userdata('nip',$idadmin);
            $this->session->set_userdata('nama',$username);
            echo $this->session->set_flashdata('msg','<div class="alert alert-succsess" role="alert"><button type="button" class="close" data-dismiss="success"><span class="fa fa-close"></span></button> Login Berhasil </div>');
            redirect('dashboard.aspx');
         }
        else if($xcadmin['akses']=='2'){
            $this->session->set_userdata('akses','2');
            $idadmin=$xcadmin['nip'];
            $username=$xcadmin['nama'];
   
            $this->session->set_userdata('nip',$idadmin);
            $this->session->set_userdata('nama',$username);
            echo $this->session->set_flashdata('msg','<div class="alert alert-succsess" role="alert"><button type="button" class="close" data-dismiss="success"><span class="fa fa-close"></span></button> Login Berhasil </div>');

            redirect('beranda.aspx');
         }

       }else{
         echo $this->session->set_flashdata('msg','<div class="alert alert-danger" role="alert"><button type="button" class="close" data-dismiss="alert"><span class="fa fa-close"></span></button> Username Atau Password Salah</div>');
         redirect('dosenx/gagallogin'); 
       }
    }



    function gagallogin(){
        $url=base_url();
        echo $this->session->set_flashdata('message','<div class="alert alert-danger" role="alert"><button type="button" class="close" data-dismiss="alert"><span class="fa fa-close"></span></button> Username Atau Password Salah</div>');
        redirect($url);
    }

    function logout(){
        $this->session->sess_destroy();
        $url=base_url('login.aspx');
        redirect($url);
    }
}