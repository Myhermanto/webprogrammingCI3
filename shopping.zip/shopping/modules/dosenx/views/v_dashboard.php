<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
<!-- BEGIN: Head-->

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="staff.bsi.ac.id">
    <meta name="keywords" content="staff.bsi.ac.id">
    <meta name="author" content="BTI-4.0">
    <title>Ruang Dosen</title>
    <link rel="apple-touch-icon" href="<?= base_url() . '' ?>assets/app-assets/images/ico/apple-icon-120.png">
    <link rel="shortcut icon" type="image/x-icon" href="<?= base_url() . '' ?>assets/app-assets/images/ico/favicon.ico">

    <?php
    $this->load->view('v_css');
    ?>

</head>
<!-- END: Head-->

<!-- BEGIN: Body-->

<body class="vertical-layout vertical-menu 2-columns   fixed-navbar" data-open="click" data-menu="vertical-menu" data-col="2-columns">



    <?php
    $this->load->view('v_header');
    $this->load->view('v_sidebar');
    ?>

    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="content-wrapper">

            <div class="content-body">
                <section id="square-callout">

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">Selamat datang di fasilitas layanan Karyawan & Dosen BSI. Fasilitas ini merupakan salah satu bentuk Informasi Pelayanan yang ditujukan untuk Karyawan BSI, dan diharapkan seluruh Jajaran Karyawan dapat memperoleh informasi tersebut dengan mudah melalui fasilitas yang di sediakan ini.</h3>

                                    <div class="heading-elements">
                                        <ul class="list-inline mb-0">
                                            <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                                            <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                            <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                                            <li><a data-action="close"><i class="ft-x"></i></a></li>
                                        </ul>
                                    </div>
                                </div>



                                <div class="card-content collapse show">
                                    <div class="card-body">
                                        <div class="bs-callout-success callout-border-left callout-square callout-bordered callout-transparent mt-1 p-1">
                                            <h3><b class='text-info'> Surat Keputusan BSI</b></h3>

                                            <div class="row">
                                            <!-- baris 1 -->
                                                <div class="col-md-6 col-sm-12">
                                                <i class="la la-angle-right"></i>  <a href="#" class="card-text"> SK Pakaian Kerja <b class='text-success'><i class=" la la-cloud-download">Download</i></b></a>
                                                </div>

                                                <div class="col-md-6 col-sm-12">
                                                <i class="la la-angle-right"></i>  <a href="#" class="card-text"> SK Keputusan Hari Dan Jam Kerja Tahun 2015 <b class='text-success'><i class=" la la-cloud-download">Download</i></b></a>
                                                </div>
                                                <!-- tutup baris 1 -->

                                                 <!--  baris 2 -->
                                                <div class="col-md-6 col-sm-12">
                                                <i class="la la-angle-right"></i>  <a href="#" class="card-text"> SK Rawat Inap <b class='text-success'><i class=" la la-cloud-download">Download</i></b></a>
                                                </div>
                                                <div class="col-md-6 col-sm-12">

                                                <i class="la la-angle-right"></i>   <a href="#" class="card-text"> SK Pemberitahuan Komplain Gaji Atau Honor <b class='text-success'><i class=" la la-cloud-download">Download</i></b></a>
                                                </div>
                                                 <!-- tutup baris 2 -->

                                                   <!--  baris 3 -->
                                                <div class="col-md-6 col-sm-12">
                                                <i class="la la-angle-right"></i>  <a href="#" class="card-text"> SK Rawat Jalan <b class='text-success'><i class=" la la-cloud-download">Download</i></b></a>
                                                </div>
                                                <div class="col-md-6 col-sm-12">

                                                <i class="la la-angle-right"></i>   <a href="#" class="card-text"> Peraturan Yayasan BSI <b class='text-success'><i class=" la la-cloud-download">Download</i></b></a>
                                                </div>
                                                 <!-- tutup baris 3 -->



                                            </div>


                                        </div>


                                        <div class="bs-callout-danger callout-border-left callout-square callout-bordered callout-transparent mt-1 p-1">
                                            <?php foreach ($penting->result_array() as $row) { ?>
                                                <p><i class="la la-hand-o-right"></i> <b><a href="#" class='text-info'><?php echo $row["Announce_title"]; ?> - (Post:<?php echo $row["Announce_date"]; ?>)</a></b></p>
                                            <?php
                                            }
                                            ?>

                                        </div>

                                        <div class="bs-callout-info callout-border-left callout-square callout-bordered callout-transparent mt-1 p-1">
                                            <?php foreach ($berita->result_array() as $row) { ?>
                                                <p><i class="la la-hand-o-right"></i> <a href="#" class='text-info'><?php echo $row["Announce_title"]; ?> - <small class='text-danger'>(Post: <?php echo $row["Announce_date"]; ?>)</small></a></p>
                                            <?php
                                            }
                                            ?>
                                          <center>      <a href="#" type="button" class="btn mr-1 mb-1 btn-outline-info btn-sm"><i class="la la-external-link"> </i>ARSIP  </a></center>

                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

            </div>
            <section id="card-bordered-options">
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <div class="card box-shadow-0 border-primary">
                            <div class="card-header card-head-inverse bg-info">
                                <h4 class="card-title text-white">SAYS</h4>
                                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                             
                            </div>
                            <div class="card-content collapse show">
                                <div class="card-body">
                                <h3><a href="#" class='text-danger'><i class="la la-external-link"> Masuk Ke Halaman SAYS </i></a></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-12">
                        <div class="card box-shadow-0 border-success">
                            <div class="card-header card-head-inverse bg-success">
                                <h4 class="card-title text-white">SISTER</h4>
                                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                             
                            </div>
                            <div class="card-content collapse show">
                                <div class="card-body">
                                <h3><a href="#" class='text-danger'><i class="la la-external-link"> Masuk Ke Halaman SISTER </i></a></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <div class="card box-shadow-0 border-info">
                            <div class="card-header card-head-inverse bg-info">
                                <h4 class="card-title text-white">Layananan Kuesioner Dosen dan Tendik</h4>
                                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                             
                            </div>
                            <div class="card-content collapse show">
                                <div class="card-body">
                                <h3><a href="#" class='text-danger'><i class="la la-external-link"> Masuk Ke Halaman SURVEI </i></a></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-12">
                        <div class="card box-shadow-0 border-warning">
                            <div class="card-header card-head-inverse bg-warning">
                                <h4 class="card-title text-white">SURAT TUGAS</h4>
                                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                             
                            </div>
                            <div class="card-content collapse show">
                                <div class="card-body">
                                <h3><a href="#" class='text-danger'><i class="la la-external-link"> Masuk Ke Halaman Surat Tugas </i></a></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <div class="card box-shadow-0 border-info">
                            <div class="card-header card-head-inverse bg-info">
                                <h4 class="card-title text-white">PEDOMAN E-LEARNING</h4>
                                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                             
                            </div>
                            <div class="card-content collapse show">
                                <div class="card-body">
                                <h3><a href="#" class='text-danger'><i class="la la-external-link"> Pedoman E-Learning Untuk Mahasiswa </i></a></h3>
                                <h3><a href="#" class='text-danger'><i class="la la-external-link"> Pedoman E-Learning Untuk Dosen </i></a></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-12">
                        <div class="card box-shadow-0 border-blue">
                            <div class="card-header card-head-inverse bg-blue">
                                <h4 class="card-title text-white">PEDOMAN KULIAH KERJA NYATA (KKN)</h4>
                                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                             
                            </div>
                            <div class="card-content collapse show">
                                <div class="card-body">
                                <h3><a href="#" class='text-danger'><i class="la la-external-link">Edaran Pelaksanaan Matakuliah Kuliah Kerja Nyata (KKN) </i></a></h3>
                                <h3><a href="#" class='text-danger'><i class="la la-external-link">Buku Pedoman Kuliah Kerja Nyata (KKN) 2020</i></a></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>






        </div>
    </div>

    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>

    <!-- BEGIN: Footer-->
    <?php
    $this->load->view('v_footer');
    $this->load->view('js');

    ?>
    <!-- END: Footer-->




</body>
<!-- END: Body-->

</html>