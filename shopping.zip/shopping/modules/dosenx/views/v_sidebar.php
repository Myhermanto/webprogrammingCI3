<div class="main-menu menu-fixed menu-light menu-accordion    menu-shadow " data-scroll-to-active="true">
        <div class="main-menu-content">
            <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
         

                <li class=" nav-item"><a href="<?= base_url().'dashboard.aspx'?>"><i class="la la-home"></i><span class="menu-title" data-i18n="eCommerce">Beranda</span></a>
                </li>

                <li class=" nav-item"><a href="#"><i class="la la-user-secret"></i><span class="menu-title" data-i18n="Project">Personal</span></a>
                    <ul class="menu-content">
                        <li><a class="menu-item" href="#"><i></i><span data-i18n="Project Summary"><i class="la la-angle-double-right"></i> Data Pribadi</span></a>
                        </li>
                        <li><a class="menu-item" href="#"><i></i><span data-i18n="Project Task"><i class="la la-angle-double-right"></i>  Honor</span></a>
                        </li>
                      
                    </ul>
                </li>
                
                <li class=" nav-item"><a href="#"><i class="la la-book"></i><span class="menu-title" data-i18n="Project">Mengajar</span></a>
                    <ul class="menu-content">
                        <li><a class="menu-item" href="#"><i></i><span data-i18n="Project Summary"><i class="la la-angle-double-right"></i> Jadwal Mengajar</span></a>
                        </li>
                        <li><a class="menu-item" href="#"><i></i><span data-i18n="Project Task"><i class="la la-angle-double-right"></i> Surat Tugas Mengajar</span></a>
                        <li><a class="menu-item" href="#"><i></i><span data-i18n="Project Task"><i class="la la-angle-double-right"></i> Cari Slide Mengajar</span></a>
                        </li>
                      
                    </ul>
                </li>
                <li class=" nav-item"><a href="#"><i class="la la-users"></i><span class="menu-title" data-i18n="Project">Master Mahasiswa</span></a>
                    <ul class="menu-content">
                        <li><a class="menu-item" href="#"><i></i><span data-i18n="Project Summary"><i class="la la-angle-double-right"></i>  Data Mahasiswa</span></a>
                        </li>
                        <li><a class="menu-item" href="#"><i></i><span data-i18n="Project Task"><i class="la la-angle-double-right"></i> Nilai Mahasiswa</span></a>
                        </li>
                      
                    </ul>
                </li>

                <li class=" nav-item"><a href="#"><i class="la la-graduation-cap"></i><span class="menu-title" data-i18n="Menu levels">Tugas Akhir / Skripsi</span></a>
                    <ul class="menu-content">

                        <li><a class="menu-item" href="#"><i></i><span data-i18n="Second level child">Mahasiswa Bimbingan</span></a>
                            <ul class="menu-content">
                                <li><a class="menu-item" href="#"><i></i><span data-i18n="Third level"><i class="la la-angle-double-right"></i> Mahasiswa Bimbingan D3/S1</span></a>
                                </li>
                                <li><a class="menu-item" href="#"><i></i><span data-i18n="Third level"><i class="la la-angle-double-right"></i> Mahasiswa Bimbingan D1</span></a>
                                </li>
                            </ul>
                        </li>

                        <li><a class="menu-item" href="#"><i></i><span data-i18n="Second level child">Jadwal Sidang</span></a>
                            <ul class="menu-content">
                                <li><a class="menu-item" href="#"><i></i><span data-i18n="Third level"><i class="la la-angle-double-right"></i> Jadwal Ujian Sidang MHS</span></a>
                                </li>
                                <li><a class="menu-item" href="#"><i></i><span data-i18n="Third level"><i class="la la-angle-double-right"></i> Jadwal Menguji</span></a>
                                </li>
                                <li><a class="menu-item" href="#"><i></i><span data-i18n="Third level"><i class="la la-angle-double-right"></i> Jadwal Ujian MHS Perbaikan</span></a>
                                </li>
                                <li><a class="menu-item" href="#"><i></i><span data-i18n="Third level"><i class="la la-angle-double-right"></i> Jadwal Menguji Sidang Perbaikan</span></a>
                                </li>
                            </ul>
                        </li>

                        <li><a class="menu-item" href="#"><i></i><span data-i18n="Second level child">Hasil Sidang</span></a>
                            <ul class="menu-content">
                                <li><a class="menu-item" href="#"><i></i><span data-i18n="Third level"><i class="la la-angle-double-right"></i> Hasil Sidang MHS (D3/S1)</span></a>
                                </li>
                                <li><a class="menu-item" href="#"><i></i><span data-i18n="Third level"><i class="la la-angle-double-right"></i> Hasil Sidang MHS (D1)</span></a>
                                </li>
                           
                                <li><a class="menu-item" href="#"><i></i><span data-i18n="Third level"><i class="la la-angle-double-right"></i> Hasil Sidang Perbaikan</span></a>
                                </li>
                            </ul>
                        </li>

                    </ul>
                </li>
            
                
                <li class=" nav-item"><a href="#" ><i class="la la-street-view"></i><span class="menu-title" data-i18n="Raise Support">Dosen PA</span></a>
                </li>
                <li class=" nav-item"><a href="#" ><i class="la la-pencil-square-o"></i><span class="menu-title" data-i18n="Raise Support">BimBimbingan KKN</span></a>
                </li>
                <li class=" nav-item"><a href="#"><i class="la la-paste"></i><span class="menu-title" data-i18n="Project">Administrasi</span></a>
                    <ul class="menu-content">
                        <li><a class="menu-item" href="#"><i></i><span data-i18n="Project Summary"><i class="la la-angle-double-right"></i> Cetak Absensi UTS</span></a>
                        </li>
                        <li><a class="menu-item" href="#"><i></i><span data-i18n="Project Task"><i class="la la-angle-double-right"></i> Cetak Absensi UAS</span></a>
                        </li>
                      
                    </ul>
                </li>
           

                <li class=" nav-item"><a href="#"><i class="la la-envelope"></i><span class="menu-title" data-i18n="Project">E-Mail</span></a>
                    <ul class="menu-content">
                        <li><a class="menu-item" href="#"><i></i><span data-i18n="Project Summary"><i class="la la-angle-double-right"></i> E-Mail Administrasi</span></a>
                        </li>
                        <li><a class="menu-item" href="#"><i></i><span data-i18n="Project Summary"><i class="la la-angle-double-right"></i> E-Mail Bagian</span></a>
                        </li>

                        <li><a class="menu-item" href="#"><i></i><span data-i18n="Project Summary"><i class="la la-angle-double-right"></i> E-Mail Dosen</span></a>
                        </li>
                      
                    </ul>
                </li>
               
                <li class=" navigation-header"><span>Bantuan</span><i class="la la-ellipsis-h" data-toggle="tooltip" data-placement="right" data-original-title="Support"></i>
                </li>
                <hr>
                <li class=" nav-item"><a href="#"><i class="la la-comments-o"></i><span class="menu-title" data-i18n="Raise Support">Tanya SDM</span></a>
                </li>
                <li class=" nav-item"><a href="#" ><i class="la la-comments-o"></i><span class="menu-title" data-i18n="Documentation">Tanya BAAK</span></a>
                </li>
            </ul>
        </div>
    </div>