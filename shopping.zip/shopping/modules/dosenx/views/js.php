
    <!-- BEGIN: Vendor JS-->
    <script src="<?= base_url().''?>assets/app-assets/vendors/js/vendors.min.js"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <script src="<?= base_url().''?>assets/app-assets/vendors/js/forms/validation/jqBootstrapValidation.js"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="<?= base_url().''?>assets/app-assets/js/core/app-menu.js"></script>
    <script src="<?= base_url().''?>assets/app-assets/js/core/app.js"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <script src="<?= base_url().''?>assets/app-assets/js/scripts/forms/form-login-register.js"></script>
    <!-- END: Page JS-->

    <script src="<?= base_url().''?>assets/app-assets/js/scripts/pages/dashboard-crypto.js"></script>
    <!-- END: Page JS-->


