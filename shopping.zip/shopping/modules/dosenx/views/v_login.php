<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
<!-- BEGIN: Head-->

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="staff.bsi.ac.id">
    <meta name="keywords" content="staff.bsi.ac.id">
    <meta name="author" content="BTI-4.0">
    <title>LOGIN - DOSEN</title>
    <link rel="apple-touch-icon" href="<?= base_url().''?>assets/app-assets/images/ico/apple-icon-120.png">
    <link rel="shortcut icon" type="image/x-icon" href="<?= base_url().''?>assets/app-assets/images/ico/favicon.ico">

    <?php
        $this->load->view('v_css');
        ?>

</head>
<!-- END: Head-->

<!-- BEGIN: Body-->

<body class="vertical-layout vertical-menu 1-column   blank-page" data-open="click" data-menu="vertical-menu" data-col="1-column">
    <!-- BEGIN: Content-->
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="content-wrapper">
            <div class="content-header row">
            </div>
            <div class="content-body">
                <section class="row flexbox-container">
                    <div class="col-12 d-flex align-items-center justify-content-center">
                        <div class="col-lg-4 col-md-8 col-10 box-shadow-2 p-0">
                            <div class="card border-grey border-lighten-3 px-2 py-2 m-0">
                                <div class="card-header border-0">
                                    <div class="card-title text-center">
                                        <!-- <img src="<?= base_url().''?>assets/app-assets/images/logo/logo-dark.png" alt="branding logo"> -->
                                 <h1><b class='text-danger'>- RUANG DOSEN -</b></h1>
                                 <div><?php echo $this->session->flashdata('msg');?></div>
                                    </div>
                    
                                </div>
                              
                                <div class="card-content">
                                    <div class="card-body">
                                        <form action="<?= base_url().'dosenx/auth'?>" method="post" class="form-horizontal form-simple" novalidate>
                                            <fieldset class="form-group position-relative has-icon-left mb-1">
                                                <input type="text" name="username" class="form-control form-control-lg input-lg" id="user-name" placeholder="NIP" required>
                                                <div class="form-control-position">
                                                    <i class="la la-user"></i>
                                                </div>
                                            </fieldset>
                              
                                            <fieldset class="form-group position-relative has-icon-left">
                                                <input type="password" name="password" class="form-control form-control-lg input-lg" id="user-password" placeholder="Enter Password" required>
                                                <div class="form-control-position">
                                                    <i class="la la-key"></i>
                                                </div>
                                            </fieldset>
                                            <button type="submit" class="btn btn-info btn-lg btn-block"><i class="ft-unlock"></i> Login</button>
                                        </form>
                                    </div>
                                    <p class="text-center">Lupa Password ? <a href="<?= base_url().'lupa-password.aspx'?>" class="card-link">Klik Disini</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

            </div>
        </div>
    </div>
    <!-- END: Content-->

    <?php
        $this->load->view('js');
        ?>

</body>
<!-- END: Body-->

</html>