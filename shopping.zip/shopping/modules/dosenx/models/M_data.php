<?php
defined('BASEPATH') or exit('No dirext script access allowed');
class M_data extends CI_Model
{

    function edit_data($where, $table)
    {
        return $this->db->get_where($table, $where);
    }
    function get_data($table)
    {
        return $this->db->get($table);
    }
    function insert_data($data, $table)
    {
        $this->db->insert($table, $data);
    }
    function update_data($where, $data, $table)
    {
        $this->db->where($where);
        $this->db->update($table, $data);
    }
    function delete_data($where, $table)
    {
        $this->db->where($where);
        $this->db->delete($table);
    }
    function pengguna_dashbord()
    {
        $id_admin = $this->session->userdata('nip');
        $hsl = $this->db->query("SELECT * FROM karyawanbs1 WHERE nip='$id_admin'");
        return $hsl;
    }
    function cekadmin($username,$password){
        $username=$this->db->escape($username);
        $password=$this->db->escape($password);
	   $hasil=$this->db->query("SELECT * FROM karyawanbs1 WHERE nip=$username AND passinter=md5($password)");
	 
	// $hasil=$this->db->query("SELECT * FROM tbl_pengguna_sekolah WHERE pengguna_username='admin1'")->result();
        return $hasil;
    }
   function get_pengguna_login($kode){
     $hsl=$this->db->query("SELECT * FROM karyawanbs1 where nip='$kode'");
     return $hsl;
   }
   

   function get_pengumuman(){
    $this->db->select('personal_berita.*');
    $this->db->from('personal_berita');
    $this->db->limit('7');
    $this->db->order_by('id', 'DESC');
    $query = $this->db->get();

    return $query;
  }

  function get_pengumuman_penting(){
    $this->db->select('personal_berita.*');
    $this->db->from('personal_berita');
    $this->db->limit('5');
    $this->db->where('penting','2');
    $this->db->order_by('id', 'DESC');
    $query = $this->db->get();

    return $query;
  }
}
