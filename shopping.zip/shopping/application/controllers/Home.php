<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home extends CI_Controller
{


	public function index()
	{
		$this->load->view('index_home');
	}


	function kontak()
	{
		$this->load->view('v_kontak');
	}

	function detail_produk()
	{
		$this->load->view('v_detail_produk');
	}
}
